# LAGFORGE — beginner runbook

This zip is the **trading engine**. It is not the visual desk you saw in the browser.

| What | Where |
| --- | --- |
| Charts, slots, PAPER/LIVE switch | The web desk (always paper) |
| Real CoinSwitch orders | This Python bot, on your PC or an AWS Mumbai server |
| Live status while it runs | Your terminal + Telegram |

Do **not** paste API keys into the web desk or into chat. They go only in a file named `.env` on your computer.

Paper is the default. Do not enable live orders until you have 72 hours of tape showing that gross divergence still beats fees after slippage. ₹10,000 at 10× can wipe the account.

---

## 1. Download and unzip

1. Download `lagforge-bot.zip` from the Python tab.
2. Unzip it. You should see a folder with `main.py`, `env.example`, and `requirements.txt`.
3. Remember that folder path (example: `Documents/lagforge-bot`).

## 2. Install Python (once)

1. Install **Python 3.11 or newer** from [python.org/downloads](https://www.python.org/downloads/).
2. On Windows, tick **Add python.exe to PATH** before you click Install.
3. Open a new terminal and check:

```bash
python --version
```

You want `Python 3.11` or `3.12`. On some Macs the command is `python3`.

## 3. Open the folder in VS Code

1. Install [VS Code](https://code.visualstudio.com/) if you do not have it.
2. Install the extension named **Python** (Microsoft).
3. File → Open Folder → select the unzipped `lagforge-bot` folder.
4. Terminal → New Terminal (this opens a prompt **inside** that folder).

## 4. Create a virtual environment and install packages

In the VS Code terminal:

```bash
python -m venv .venv
```

Activate it:

- **Windows:** `.venv\Scripts\activate`
- **Mac / Linux:** `source .venv/bin/activate`

You should see `(.venv)` at the start of the line. Then:

```bash
pip install -r requirements.txt
```

## 5. Create your secret file

```bash
cp env.example .env
```

On Windows PowerShell:

```powershell
copy env.example .env
```

Open `.env` in VS Code. Fill only what you need for paper:

```
PAPER_TRADING=true
CONFIRM_LIVE=

TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_CHAT_ID=your_chat_id

STARTING_CAPITAL_INR=10000
```

Leave CoinSwitch keys empty for paper. If the CoinSwitch feed fails on your home network, set:

```
ALLOW_SYNTHETIC_LAG=true
```

Turn that **off** before the real 72-hour calibration (that mode delays Binance locally; it is not a true CoinSwitch book).

Save the file. Never commit `.env`. Never send it to anyone.

## 6. Run paper (this is the next step)

Still in the VS Code terminal, with `(.venv)` active:

```bash
python latency_bench.py
python main.py
```

Leave that window open. You should get:

- Lines in the terminal as slots arm and trades print
- Telegram messages on each fill and every hour

That is the interface for the live engine. There is no copy of the web desk inside this zip.

Stop it with `Ctrl+C`.

## 7. AWS EC2 (Mumbai) — only after paper works on your PC

Use region **ap-south-1**. A small Ubuntu 22.04 box (t3.small) is enough.

1. Create the instance. Allow **SSH inbound from your IP only**. Outbound HTTPS must be open.
2. Copy this folder to the server (FileZilla, WinSCP, or `scp`).
3. SSH in, install Python, recreate the venv, copy `.env` (create it on the server — do not email it).
4. Run `python latency_bench.py`. You want CoinSwitch round-trip in the low tens of milliseconds from Mumbai.
5. Install the service so it survives reboot:

```bash
sudo cp deploy/lagforge.service /etc/systemd/system/lagforge.service
```

Edit that file so `WorkingDirectory` and `EnvironmentFile` point at **your** path, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now lagforge
sudo journalctl -u lagforge -f
```

Keep `PAPER_TRADING=true` on the server until the 72-hour tape is done.

## 8. Going live (after 72h paper)

Only if net edge survived fees across Asia, London, and US hours.

In `.env` **on the server** (not in the web desk):

```
COINSWITCH_API_KEY=...
COINSWITCH_SECRET_KEY=...
PAPER_TRADING=false
CONFIRM_LIVE=YES
```

Both flags are required. Restart the service. Keys stay on that box.

Live orders hit CoinSwitch PRO crypto futures (`POST /trade/api/v2/futures/order`, Ed25519). Contracts are USDT-margined; ₹ is how we size and report.

---

## What the engine does

- Binance Futures bookTicker is the lead (WebSocket, never REST for signals).
- CoinSwitch PRO futures order book is the lag.
- Equal-weight slots from ₹10,000 / 10. One open position per coin.
- LONG if Binance mid > CoinSwitch best ask by more than fees + slippage.
- SHORT if Binance mid < CoinSwitch best bid by the same hurdle.
- Target and timeout flatten **only if the close is net-green after fees**. The vol stop is the only loss exit.
- SQLite recovers open slots after a crash.

## Notes on ₹10,000 / 10 slots

At ~₹96/USDT a ₹1,000 slot with 10× is ~$104 notional. The screener drops any coin whose min contract exceeds slot notional.

## Files

| File | Module |
| --- | --- |
| `data_ingestion.py` | DataIngestion |
| `signal_engine.py` | SignalEngine |
| `portfolio.py` | PortfolioManager |
| `order_executor.py` | OrderExecutor |
| `risk_manager.py` | RiskManager |
| `telegram_reporter.py` | TelegramReporter |
| `persistence.py` | SQLite crash recovery |
| `latency_bench.py` | RTT probe |
| `rate_limit.py` | Token bucket |
